GROOMLAND COLLEGE WEBSITE — UPDATED PHOTO EDITION

Contents:
- index.html — responsive Groomland College website
- assets/groomland-logo-original.jpg — original school crest image (preserved)
- assets/gallery/ — selected learner and study photographs supplied and approved by the school
- assets/campus/ — selected school building and grounds image
- assets/admissions/ — selected enrolment and programme flyers

The uploaded photographs and flyers have been placed on the site without altering the students' appearances or changing the supplied artwork. The website retains its WhatsApp contact, Facebook link and Tawk.to live-chat integration.

DEPLOYMENT
Upload the contents of this ZIP (index.html and the complete assets folder) to the website hosting document root connected to www.groomland.co.zw. Keep the assets folder structure unchanged. Replace the previous website files with this updated package. The website package is ready; it has not been published to the live domain from this workspace.


Gallery refresh (12 November 2026): The school gallery now uses the eight newly supplied photographs: one learner group, six campus/building views, and one classroom study photo. The existing website layout, school logo, admissions flyers, contact details, and social links have been retained.
